package com.lizongying.mytv.models


data class EPG(
    val title: String,
    val beginTime: Int,
)
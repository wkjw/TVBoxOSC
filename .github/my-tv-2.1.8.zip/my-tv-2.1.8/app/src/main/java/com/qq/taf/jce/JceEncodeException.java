package com.qq.taf.jce;

public class JceEncodeException extends RuntimeException {
    public JceEncodeException(String str) {
        super(str);
    }
}

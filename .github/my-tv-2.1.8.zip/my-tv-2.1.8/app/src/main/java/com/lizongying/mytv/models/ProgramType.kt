package com.lizongying.mytv.models

enum class ProgramType {
    Y_PROTO,
    Y_JCE,
    F,
}
package com.lizongying.mytv.requests


data class ReleaseResponse(
    val version_code: Int?,
    val version_name: String?,
)
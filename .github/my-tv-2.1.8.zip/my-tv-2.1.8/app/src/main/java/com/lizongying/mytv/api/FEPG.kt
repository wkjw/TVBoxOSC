package com.lizongying.mytv.api


data class FEPG(
    val title: String,
    val event_time: String,
)
package com.qq.taf.jce;

public class JceDecodeException extends RuntimeException {
    public JceDecodeException(String str) {
        super(str);
    }
}

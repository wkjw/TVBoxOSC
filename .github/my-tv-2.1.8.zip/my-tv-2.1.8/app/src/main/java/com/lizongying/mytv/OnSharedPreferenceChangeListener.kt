package com.lizongying.mytv


interface OnSharedPreferenceChangeListener {
    fun onSharedPreferenceChanged(key: String)
}